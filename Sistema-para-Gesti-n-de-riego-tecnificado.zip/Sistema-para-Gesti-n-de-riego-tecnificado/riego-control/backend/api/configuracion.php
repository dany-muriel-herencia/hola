<?php
require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json');

try {
    $db = Database::getConnection();

    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $stmt = $db->query("SELECT valor FROM configuracion WHERE clave = 'cola_maxima'");
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        echo json_encode(['success' => true, 'cola_maxima' => $row ? intval($row['valor']) : 2]);
    } 
    elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $data = json_decode(file_get_contents("php://input"), true);
        if (isset($data['cola_maxima'])) {
            $nuevo_valor = max(1, intval($data['cola_maxima']));
            $stmt = $db->prepare("INSERT INTO configuracion (clave, valor) VALUES ('cola_maxima', :valor) ON DUPLICATE KEY UPDATE valor = VALUES(valor)");
            $stmt->execute(['valor' => $nuevo_valor]);
            echo json_encode(['success' => true, 'cola_maxima' => $nuevo_valor]);
        } else {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Falta parametro cola_maxima']);
        }
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
