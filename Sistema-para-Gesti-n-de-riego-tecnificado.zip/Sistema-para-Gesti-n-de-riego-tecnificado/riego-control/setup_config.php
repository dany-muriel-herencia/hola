<?php
require_once __DIR__ . '/backend/config/database.php';
$db = Database::getConnection();
$db->exec("CREATE TABLE IF NOT EXISTS configuracion (clave VARCHAR(50) PRIMARY KEY, valor VARCHAR(255))");
$db->exec("INSERT IGNORE INTO configuracion (clave, valor) VALUES ('cola_maxima', '2')");
echo "OK\n";
